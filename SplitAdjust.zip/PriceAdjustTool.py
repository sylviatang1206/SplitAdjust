import pandas as pd
import datetime as dt


class PriceAdjustTool:
    def __init__(self, _adjust_item, _cut_off_date, _price_file_name, _adjust_info_file_name):
        # check inputs and load data
        if _adjust_item == 'Split':
            print('Welcome to split adjustment method')
            self.adjust_item = _adjust_item
        elif _adjust_item == 'Dividend':
            print('Method is under development')
        else:
            print('No related method!')

        if isinstance(_cut_off_date, dt.datetime):
            print('Added cut_off_date')
            self.cut_off_date = _cut_off_date
        else:
            print('cut off date must be datetime type!')

        # try to load data from local repository
        try:
            self.price_info_df = pd.read_csv(_price_file_name)
            self.adjust_info_df = pd.read_csv(_adjust_info_file_name)
        except ValueError:
            print('Some value error for data loading')

        # if the adjust item is Split
        if self.adjust_item == 'Split':
            # convert string series to datetime series
            self.adjust_info_df['SplitDate'] = pd.to_datetime(self.adjust_info_df['SplitDate'])
            self.adjust_info_df['NextSplitDate'] = pd.to_datetime(self.adjust_info_df['NextSplitDate'])
            self.price_info_df['pricingDate'] = pd.to_datetime(self.price_info_df['pricingDate'])
            self.split_info_df_cut_off_df = self.adjust_info_df[self.adjust_info_df['SplitDate'] < self.cut_off_date]

            # initialize split factor dictionary for each asset
            self.split_dic = {}

            # initialize result dataframe for the price info dataframe
            self.result_df = pd.DataFrame()

    # use this function to warm up the tool, potentially we can save the dictionary as a pickle file to imporve speed
    def warm_up(self):
        if self.adjust_item == 'Split':
            group_by_id_adjust_info = self.adjust_info_df.groupby('id')
            for single_id, df in group_by_id_adjust_info:
                culmulative_factor = df['latestSplitFactor'][::-1].cumprod().tolist()
                del culmulative_factor[-1]
                culmulative_factor.insert(0, 1)
                df['SplitFactor'] = culmulative_factor[::-1]
                self.split_dic[single_id] = df
        else:
            print('Under development')

    # add a column of split factor
    def addsplitfactor(self):
        group_by_id_price = self.price_info_df.groupby('id')
        df_result = pd.DataFrame()
        for single_id, df in group_by_id_price:
            if single_id in self.split_dic:
                temp_split_info_df = self.split_dic[single_id]
                df['SplitFactor'] = 1
                for index, row in temp_split_info_df.iterrows():
                    print((df['pricingDate'] > row['SplitDate']) & (df['pricingDate'] < row['NextSplitDate']))
                    df[(df['pricingDate'] > row['SplitDate']) & (df['pricingDate'] < row['NextSplitDate'])][
                        'SplitFactor'][:] = \
                        row['SplitFactor']
            else:
                df['SplitFactor'] = 1
            pd.concat(df_result, df)

        return df_result.sort_values(by=['pricingDate'])


def main():
    adjust_item = 'Split'
    cut_off_date = dt.datetime(2018, 12, 31)
    # cut_off_date = dt.datetime(2019, 3, 29)
    price_file_name = 'price_volume_20171231_20181231.csv'
    adjust_file_name = 'splitinfo_20171231_20181231.csv'

    price_adjust_tool_object = PriceAdjustTool(adjust_item, cut_off_date, price_file_name, adjust_file_name)
    price_adjust_tool_object.warm_up()
    result_df = price_adjust_tool_object.addsplitfactor()


if __name__ == '__main__':
    main()
